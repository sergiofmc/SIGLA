<?php
//Contact form config
$email_to = "support@themeleaf.com";
$email_subject = "Feedback form submitted";

//recaptcha config
$use_recaptcha = true;
$publickey = "6LeMXt4SAAAAABbnTq7FvelG2GANlmpl_sWvWP0b";
$privatekey = "6LeMXt4SAAAAAFZ7CGFwmppH5bD2W1gA1Nvpflvs";
?>
