<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'KEY-HERE');
define('CONSUMER_SECRET', 'SECRET-HERE');
define('OAUTH_CALLBACK', 'http://127.0.0.1/sandbox/new/twitteroauth-master/index.php');
